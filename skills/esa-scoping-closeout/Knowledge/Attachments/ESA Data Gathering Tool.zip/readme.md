# ESA Data Export Tool — User Guide

## What This Tool Does

The **ESA Data Export Tool** collects security data from your Azure environment for the **Enterprise Security Assessment (ESA)**. It exports Defender for Cloud recommendations and compliance data, which are then analyzed by your Microsoft CSA in a Power BI report.

The tool collects **two of the four required data sources** automatically:

| # | Data Source | Method |
|---|------------|--------|
| 1 | Defender for Cloud — Recommendations (MDC) | ✅ Automated by this tool |
| 2 | Defender for Cloud — MCSB Compliance | ✅ Automated by this tool |
| 3 | Microsoft Defender XDR — Secure Score | ⚠ Manual export required |
| 4 | Microsoft Purview — Compliance Manager | ⚠ Manual export required |

---

## Prerequisites

Before running the tool, ensure the following:

### Software

- **PowerShell 7.x** is required (Windows PowerShell 5.x is NOT supported)
  - Download: https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-windows
- **Az.Accounts** and **Az.ResourceGraph** PowerShell modules

  Install both modules by running this command in PowerShell 7:
  ```powershell
  Install-Module Az.Accounts, Az.ResourceGraph -Force
  ```

### Permissions

| Data Source | Required Role |
|-------------|---------------|
| Defender for Cloud (MDC + MCSB) | **Security Reader** or **Reader** on target Azure subscriptions |
| Microsoft Defender XDR | **Entra ID Global Reader** |
| Microsoft Purview | **Compliance Manager Reader** or **Entra ID Global Reader** |

### Important Rules

- **Do NOT run as Administrator** — use standard user rights only
- **Do NOT run in Azure Cloud Shell** — the tool must run locally
- After downloading, you may need to **unblock** the `.ps1` file (right-click → Properties → Unblock)

---

## How to Start

1. Open **PowerShell 7** (not Windows PowerShell)
2. Navigate to the folder containing the tool files
3. Run:
   ```powershell
   .\ESA_GUI.ps1
   ```

The wizard will guide you through all steps.

---

## Step-by-Step Walkthrough

### Step 1: Prerequisites Check

The tool verifies that all requirements are met. If any check fails (red ❌), resolve the issue before proceeding. Common fixes:

| Problem | Solution |
|---------|----------|
| PowerShell version too old | Install PowerShell 7.x from the link above |
| Missing Az modules | Run `Install-Module Az.Accounts, Az.ResourceGraph -Force` |
| Running as Administrator | Close the window and reopen PowerShell without "Run as Administrator" |

### Step 2: Export Type

Choose what to export:

- **MDC Recommendations** — Defender for Cloud security recommendations
- **MCSB Compliance** — Microsoft Cloud Security Benchmark compliance data
- **Both** (recommended) — Exports MDC first, then MCSB automatically

> **Recommendation:** Select **Both** to collect all automated data in one run.

### Step 3: Sign In

- If you already have an active Azure session, the tool detects it and shows your current account and tenant. Click **Use Current Session** to continue.
- If no session exists, click **Sign In** to authenticate with your Azure account.
- If you need to switch accounts, click **Re-Sign In**.

### Step 4: Tenant Selection

- If your account has access to only one tenant, it is auto-selected.
- If you have multiple tenants, select the one that contains the subscriptions you want to assess.

### Step 5: Subscription Selection

This step lists all subscriptions in the selected tenant. Each subscription shows a **Defender for Cloud readiness icon**:

| Icon | Meaning | Action Needed |
|------|---------|---------------|
| ✅ | **Fully onboarded** — all Defender plans on Standard tier | No action — ready for assessment |
| ⚠️ | **Partially onboarded** — some plans Standard, some Free | Consider enabling remaining plans |
| ⚠️ | **Foundational CSPM only** — no paid Defender plans | Defender for Cloud should be enabled (see [Troubleshooting](#defender-for-cloud-not-enabled)) |

- **Select All** to include all subscriptions (recommended for a complete assessment)
- Use the **search filter** to find specific subscriptions
- Subscriptions are unchecked by default — you must select at least one

### Step 6: Output Settings

- Choose the output folder where CSV files will be saved
- Review the configuration summary before starting

### Step 7: Export

- The export runs automatically. You can monitor progress via:
  - **Overall progress bar** — subscriptions processed
  - **Current progress bar** — records retrieved for current subscription
  - **Log window** — detailed export activity
- **Cancel** is available if needed
- Depending on the number of subscriptions and data volume, the export may take several minutes to hours

### Step 8: Results

After the export completes, the Results page shows:

- Total records exported
- Duration
- Defender for Cloud Secure Score (auto-captured)
- **Subscription Warnings** — any subscriptions with missing or incomplete data

### Step 9: Manual Exports

The tool reminds you to manually export the remaining two data sources:

#### Microsoft Defender XDR (Secure Score)
1. Navigate to https://security.microsoft.com/securescore
2. **Note the Secure Score value** (take a screenshot)
3. Select the **Recommended actions** tab
4. Click **Export** to download the CSV

#### Microsoft Purview (Compliance Manager)
1. Navigate to https://purview.microsoft.com/compliancemanager/improvementactionspage
2. Ensure **no filters are applied** (all filters set to "Any")
3. Click **Export actions** to download the Excel file

### Step 10: Final Checklist & Export Log

- Review the checklist to confirm all data has been collected
- Check the **Export Statistics** for any data gaps
- Click **Export Log and Create ZIP** to package all files
- Click **Open Output Folder** to access the files
- Share the generated ZIP file with your Microsoft CSA

---

## Troubleshooting

### Defender for Cloud Not Enabled

**Symptom:** Subscriptions show ⚠️ "Foundational CSPM only" on the subscription selection page, and the Results page shows warnings about missing data.

**What it means:** Only the free baseline (Foundational CSPM) is active. No paid Defender plans are configured, which means the assessment will have limited or no data for these subscriptions.

**What to do:**

1. **Option A — Proceed with current data:** You can run the assessment with the available data. The CSA will note the gaps in the report. This is acceptable if you want a partial assessment.

2. **Option B — Enable Defender for Cloud first:** For a complete assessment, enable Defender for Cloud on the affected subscriptions before re-running the export.

   Best practice is to onboard at the **management group level** to ensure consistent coverage:
   - [Onboard a management group — Microsoft Defender for Cloud](https://learn.microsoft.com/en-us/azure/defender-for-cloud/onboard-management-group)
   - Enable the required Defender plans based on your workloads (Servers, Storage, SQL, Containers, Key Vault, App Service, etc.)
   - Assign the **Microsoft Cloud Security Benchmark (MCSB)** as the default security policy

   > After enabling Defender for Cloud, wait **24 hours** for the initial data collection to complete before re-running the export.

3. **Option C — Engage your CSA:** Your Microsoft CSA can help remediate these gaps. If needed, a **Technical Blocker Mitigation VBD** for Defender for Cloud onboarding can be dispatched.

### Partially Onboarded Subscriptions

**Symptom:** Subscriptions show ⚠️ "Partially onboarded" — some Defender plans are on Standard tier, some are on Free tier.

**What it means:** Data will be exported but may be incomplete. Only the enabled plans produce recommendations; areas covered by Free-tier plans will have limited visibility.

**What to do:** Consider enabling the remaining Defender plans. The subscription selection tooltip shows which plans are still on Free tier.

### Missing Permissions

**Symptom:** Export fails for certain subscriptions with "Missing permissions" in the warnings.

**What to do:** Ensure your account has at least **Security Reader** or **Reader** role on the affected subscriptions. Contact your Azure administrator to request access.

### Export Takes Very Long

Large environments (hundreds of subscriptions, many resources) can take a long time. This is normal. The tool shows progress and can be cancelled and re-run.

### No Secure Score Data

**Symptom:** "No Secure Score data found" in the export log.

**What it means:** Defender for Cloud is not onboarded on the selected subscriptions, so no Secure Score is available.

**What to do:** See [Defender for Cloud Not Enabled](#defender-for-cloud-not-enabled) above.

---

## What to Share with Your CSA

After completing all steps, provide your Microsoft CSA with:

1. **The ZIP file** generated by the tool (contains export log + CSV files)
2. **Microsoft Defender XDR CSV** (manually exported)
3. **Microsoft Purview Excel** (manually exported)
4. **Secure Score screenshots** (Defender for Cloud + Microsoft Secure Score)

---

## Files in This Package

| File | Description |
|------|-------------|
| `ESA_GUI.ps1` | The graphical wizard tool (recommended) |
| `ESA_MDC_DataExport.ps1` | Command-line export script (alternative) |
| `MDC_Params.json` | Configuration for MDC Recommendations export |
| `MCSB_Params.json` | Configuration for MCSB Compliance export |
| `MDC.kql` | KQL query for MDC data |
| `MCSB.kql` | KQL query for MCSB data |
