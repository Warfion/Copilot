#Requires -Version 7.0
# ESA Data Export Tool — WPF GUI
# Version 1.1

# ── Guard: must NOT run as admin ──
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($isAdmin) {
    Write-Host "Error: This tool must NOT be run as Administrator!" -ForegroundColor Red
    exit 1
}

# ── Guard: must NOT run in Azure Cloud Shell ──
if ($env:AZUREPS_HOST_ENVIRONMENT -match 'cloud-shell' -or $env:ACC_CLOUD -eq 'true') {
    Write-Host "Error: This tool must not be executed within Azure Cloud Shell." -ForegroundColor Red
    exit 1
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms

# ══════════════════════════════════════════════════════════════════════════════
# XAML — Main Window with Wizard Steps
# ══════════════════════════════════════════════════════════════════════════════
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="ESA Data Export Tool v1.1.0" Height="680" Width="900"
        WindowStartupLocation="CenterScreen" ResizeMode="CanResizeWithGrip"
        Background="#F3F3F3" MinHeight="600" MinWidth="800">
    <Window.Resources>
        <Style x:Key="StepLabel" TargetType="TextBlock">
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="Foreground" Value="#666666"/>
        </Style>
        <Style x:Key="StepLabelActive" TargetType="TextBlock">
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="Foreground" Value="#0078D4"/>
        </Style>
        <Style x:Key="StepLabelDone" TargetType="TextBlock">
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="Foreground" Value="#107C10"/>
        </Style>
        <Style x:Key="SectionTitle" TargetType="TextBlock">
            <Setter Property="FontSize" Value="20"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Margin" Value="0,0,0,12"/>
            <Setter Property="Foreground" Value="#1A1A1A"/>
        </Style>
        <Style x:Key="NavButton" TargetType="Button">
            <Setter Property="Padding" Value="20,8"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Margin" Value="6,0"/>
            <Setter Property="Background" Value="#0078D4"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Style.Triggers>
                <Trigger Property="IsEnabled" Value="False">
                    <Setter Property="Background" Value="#CCCCCC"/>
                    <Setter Property="Foreground" Value="#888888"/>
                </Trigger>
            </Style.Triggers>
        </Style>
        <Style x:Key="NavButtonSecondary" TargetType="Button">
            <Setter Property="Padding" Value="20,8"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Margin" Value="6,0"/>
            <Setter Property="Background" Value="#E1E1E1"/>
            <Setter Property="Foreground" Value="#333333"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
        </Style>
    </Window.Resources>
    <Grid>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="200"/>
            <ColumnDefinition Width="1"/>
            <ColumnDefinition Width="*"/>
        </Grid.ColumnDefinitions>

        <!-- Left sidebar: step navigation -->
        <Border Grid.Column="0" Background="#FAFAFA" BorderBrush="#E0E0E0" BorderThickness="0,0,1,0">
            <StackPanel Margin="0,16,0,0" Name="StepPanel">
                <TextBlock Name="Step0Label" Text="Prerequisites" Style="{StaticResource StepLabelActive}"/>
                <TextBlock Name="Step1Label" Text="Export Type" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step2Label" Text="Sign In" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step3Label" Text="Tenant" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step4Label" Text="Subscriptions" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step5Label" Text="Output" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step6Label" Text="Export" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step7Label" Text="Results" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step8Label" Text="Manual Exports" Style="{StaticResource StepLabel}"/>
                <TextBlock Name="Step9Label" Text="Checklist" Style="{StaticResource StepLabel}"/>
            </StackPanel>
        </Border>

        <!-- Separator -->
        <Border Grid.Column="1" Background="#E0E0E0"/>

        <!-- Main content area -->
        <Grid Grid.Column="2">
            <Grid.RowDefinitions>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <!-- Pages (TabControl without headers) -->
            <TabControl Name="WizardPages" Grid.Row="0" BorderThickness="0" Background="Transparent" Margin="24,16,24,0">
                <TabControl.ItemContainerStyle>
                    <Style TargetType="TabItem">
                        <Setter Property="Visibility" Value="Collapsed"/>
                    </Style>
                </TabControl.ItemContainerStyle>

                <!-- ═══ Step 0: Prerequisites ═══ -->
                <TabItem>
                    <ScrollViewer VerticalScrollBarVisibility="Auto">
                        <StackPanel>
                            <TextBlock Text="Prerequisites Check" Style="{StaticResource SectionTitle}"/>
                            <TextBlock Text="Checking system requirements..." Foreground="#666" Margin="0,0,0,16"/>
                            <StackPanel Name="PrereqPanel" Margin="0,0,0,12"/>
                            <TextBlock Name="PrereqMessage" TextWrapping="Wrap" Margin="0,8,0,0"/>
                            <Border Name="PrereqPermInfo" Background="#FFF8E1" BorderBrush="#FFD54F" BorderThickness="1" CornerRadius="4" Padding="12" Margin="0,16,0,0">
                                <StackPanel>
                                    <TextBlock FontWeight="SemiBold" Text="Required Azure Permissions" Margin="0,0,0,6"/>
                                    <TextBlock TextWrapping="Wrap" Text="Security Reader or Reader role on target Azure subscriptions for Defender for Cloud data." Margin="0,0,0,4"/>
                                    <TextBlock TextWrapping="Wrap" Text="Entra ID Global Reader for Microsoft Defender XDR export." Margin="0,0,0,4"/>
                                    <TextBlock TextWrapping="Wrap" Text="Compliance Manager Reader or Entra ID Global Reader for Microsoft Purview export."/>
                                </StackPanel>
                            </Border>
                        </StackPanel>
                    </ScrollViewer>
                </TabItem>

                <!-- ═══ Step 1: Export Type ═══ -->
                <TabItem>
                    <StackPanel>
                        <TextBlock Text="Select Export Type" Style="{StaticResource SectionTitle}"/>
                        <TextBlock Text="Choose the data you want to export:" Foreground="#666" Margin="0,0,0,16"/>
                        <RadioButton Name="RadioBoth" GroupName="ExportType" IsChecked="True" Margin="0,0,0,12">
                            <StackPanel Margin="4,0,0,0">
                                <TextBlock FontWeight="SemiBold" FontSize="14" Text="Both (MDC + MCSB)"/>
                                <TextBlock Foreground="#666" TextWrapping="Wrap" Text="Run both exports sequentially in a single session"/>
                            </StackPanel>
                        </RadioButton>
                        <RadioButton Name="RadioMDC" GroupName="ExportType" Margin="0,0,0,12">
                            <StackPanel Margin="4,0,0,0">
                                <TextBlock FontWeight="SemiBold" FontSize="14" Text="MDC Recommendations"/>
                                <TextBlock Foreground="#666" TextWrapping="Wrap" Text="Defender for Cloud secure score, recommendations, and remediation details"/>
                            </StackPanel>
                        </RadioButton>
                        <RadioButton Name="RadioMCSB" GroupName="ExportType" Margin="0,0,0,12">
                            <StackPanel Margin="4,0,0,0">
                                <TextBlock FontWeight="SemiBold" FontSize="14" Text="MCSB Compliance"/>
                                <TextBlock Foreground="#666" TextWrapping="Wrap" Text="Microsoft Cloud Security Benchmark regulatory compliance assessments"/>
                            </StackPanel>
                        </RadioButton>
                    </StackPanel>
                </TabItem>

                <!-- ═══ Step 2: Sign In ═══ -->
                <TabItem>
                    <StackPanel>
                        <TextBlock Text="Azure Sign In" Style="{StaticResource SectionTitle}"/>
                        <Border Name="SessionInfoPanel" Background="#E8F5E9" BorderBrush="#A5D6A7" BorderThickness="1" CornerRadius="4" Padding="12" Margin="0,0,0,12" Visibility="Collapsed">
                            <StackPanel>
                                <TextBlock FontWeight="SemiBold" Text="Existing session detected" Margin="0,0,0,6"/>
                                <TextBlock Name="SessionAccount" TextWrapping="Wrap"/>
                                <TextBlock Name="SessionTenant" TextWrapping="Wrap"/>
                                <StackPanel Orientation="Horizontal" Margin="0,10,0,0">
                                    <Button Name="BtnUseSession" Content="Use This Session" Style="{StaticResource NavButton}" Margin="0,0,8,0"/>
                                    <Button Name="BtnReSignIn" Content="Re-Sign In" Style="{StaticResource NavButtonSecondary}"/>
                                </StackPanel>
                            </StackPanel>
                        </Border>
                        <Border Name="NoSessionPanel" Background="#FFF3E0" BorderBrush="#FFB74D" BorderThickness="1" CornerRadius="4" Padding="12" Visibility="Collapsed">
                            <StackPanel>
                                <TextBlock Text="No active Azure session found." Margin="0,0,0,8"/>
                                <Button Name="BtnSignIn" Content="Sign In to Azure" Style="{StaticResource NavButton}" HorizontalAlignment="Left"/>
                            </StackPanel>
                        </Border>
                        <TextBlock Name="SignInStatus" Foreground="#666" Margin="0,12,0,0" TextWrapping="Wrap"/>
                    </StackPanel>
                </TabItem>

                <!-- ═══ Step 3: Tenant Selection ═══ -->
                <TabItem>
                    <StackPanel>
                        <TextBlock Text="Select Tenant" Style="{StaticResource SectionTitle}"/>
                        <TextBlock Name="TenantSubtitle" Text="Your account has access to multiple tenants. Select one:" Foreground="#666" Margin="0,0,0,16"/>
                        <ListBox Name="TenantList" MinHeight="120" MaxHeight="300" Margin="0,0,0,8"/>
                        <TextBlock Name="TenantAutoSkip" Foreground="#107C10" Visibility="Collapsed" Text="Only one tenant available — auto-selected."/>
                    </StackPanel>
                </TabItem>

                <!-- ═══ Step 4: Subscriptions ═══ -->
                <TabItem>
                    <Grid>
                        <Grid.RowDefinitions>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="*"/>
                            <RowDefinition Height="Auto"/>
                        </Grid.RowDefinitions>
                        <TextBlock Text="Select Subscriptions" Style="{StaticResource SectionTitle}" Grid.Row="0"/>
                        <TextBox Name="SubFilter" Grid.Row="1" Margin="0,0,0,8" Padding="6,4" FontSize="13" ToolTip="Filter subscriptions by name or ID"/>
                        <StackPanel Orientation="Horizontal" Grid.Row="2" Margin="0,0,0,8">
                            <Button Name="BtnSelectAll" Content="Select All" FontSize="12" Padding="10,4" Margin="0,0,8,0" Cursor="Hand"/>
                            <Button Name="BtnUnselectAll" Content="Unselect All" FontSize="12" Padding="10,4" Margin="0,0,16,0" Cursor="Hand"/>
                            <TextBlock Name="SubCount" Foreground="#666" VerticalAlignment="Center" FontSize="13"/>
                        </StackPanel>
                        <ListBox Name="SubList" Grid.Row="3" SelectionMode="Multiple" ScrollViewer.VerticalScrollBarVisibility="Auto" MaxHeight="300"/>
                        <Border Grid.Row="4" Background="#F5F5F5" CornerRadius="4" Padding="10" Margin="0,10,0,0">
                            <StackPanel>
                                <TextBlock FontWeight="SemiBold" Text="Defender for Cloud Readiness" FontSize="12" Margin="0,0,0,4"/>
                                <TextBlock FontSize="12" Foreground="#333" Text="&#x2705;  Fully onboarded — all Defender plans on Standard tier"/>
                                <TextBlock FontSize="12" Foreground="#333" Text="&#x26A0;  Partially onboarded — some plans on Standard, some on Free"/>
                                <TextBlock FontSize="12" Foreground="#333" Text="&#x26A0;  Foundational CSPM only — all plans on Free tier or no Defender plans configured"/>
                            </StackPanel>
                        </Border>
                    </Grid>
                </TabItem>

                <!-- ═══ Step 5: Output Settings ═══ -->
                <TabItem>
                    <StackPanel>
                        <TextBlock Text="Output Settings" Style="{StaticResource SectionTitle}"/>
                        <TextBlock Text="Output Folder" FontWeight="SemiBold" Margin="0,0,0,6"/>
                        <DockPanel Margin="0,0,0,16">
                            <Button Name="BtnBrowse" Content="Browse" DockPanel.Dock="Right" Style="{StaticResource NavButtonSecondary}" Margin="8,0,0,0"/>
                            <TextBox Name="TxtOutputFolder" IsReadOnly="True" Padding="6,6" FontSize="13" Background="White"/>
                        </DockPanel>
                        <TextBlock Text="Output File (auto-generated)" FontWeight="SemiBold" Margin="0,0,0,6"/>
                        <TextBox Name="TxtOutputFile" IsReadOnly="True" Padding="6,6" FontSize="13" Background="#F5F5F5" Foreground="#666" Margin="0,0,0,16"/>
                        <Border Background="#F5F5F5" CornerRadius="4" Padding="16" Margin="0,8,0,0">
                            <StackPanel>
                                <TextBlock Text="Summary" FontWeight="SemiBold" FontSize="14" Margin="0,0,0,8"/>
                                <TextBlock Name="SummaryExportType" Foreground="#333"/>
                                <TextBlock Name="SummaryTenant" Foreground="#333"/>
                                <TextBlock Name="SummarySubCount" Foreground="#333"/>
                                <TextBlock Name="SummaryOutput" Foreground="#333"/>
                            </StackPanel>
                        </Border>
                    </StackPanel>
                </TabItem>

                <!-- ═══ Step 6: Export Progress ═══ -->
                <TabItem>
                    <Grid>
                        <Grid.RowDefinitions>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="*"/>
                            <RowDefinition Height="Auto"/>
                        </Grid.RowDefinitions>
                        <TextBlock Text="Exporting Data..." Style="{StaticResource SectionTitle}" Grid.Row="0" Name="ExportTitle"/>
                        <StackPanel Grid.Row="1" Margin="0,0,0,8">
                            <TextBlock Text="Overall Progress" FontWeight="SemiBold" Margin="0,0,0,4"/>
                            <ProgressBar Name="ProgressOverall" Height="20" Minimum="0" Maximum="100" Value="0"/>
                            <TextBlock Name="ProgressOverallText" Foreground="#666" Margin="0,4,0,0"/>
                        </StackPanel>
                        <StackPanel Grid.Row="2" Margin="0,0,0,8">
                            <TextBlock Name="ProgressCurrentLabel" Text="Current Subscription" FontWeight="SemiBold" Margin="0,0,0,4"/>
                            <ProgressBar Name="ProgressCurrent" Height="14" Minimum="0" Maximum="100" Value="0"/>
                            <TextBlock Name="ProgressCurrentText" Foreground="#666" Margin="0,4,0,0"/>
                        </StackPanel>
                        <TextBlock Text="Log" FontWeight="SemiBold" Grid.Row="3" Margin="0,8,0,4"/>
                        <TextBox Name="ExportLog" Grid.Row="4" IsReadOnly="True" TextWrapping="Wrap"
                                 VerticalScrollBarVisibility="Auto" FontFamily="Consolas" FontSize="12"
                                 Background="#1E1E1E" Foreground="#D4D4D4" Padding="8" AcceptsReturn="True"/>
                        <StackPanel Orientation="Horizontal" Grid.Row="5" HorizontalAlignment="Right" Margin="0,8,0,0">
                            <TextBlock Name="ExportElapsed" Foreground="#666" VerticalAlignment="Center" Margin="0,0,12,0"/>
                            <Button Name="BtnCancel" Content="Cancel" Style="{StaticResource NavButtonSecondary}"/>
                        </StackPanel>
                    </Grid>
                </TabItem>

                <!-- ═══ Step 7: Results ═══ -->
                <TabItem>
                    <ScrollViewer VerticalScrollBarVisibility="Auto">
                        <StackPanel>
                            <TextBlock Name="ResultTitle" Text="Export Complete" Style="{StaticResource SectionTitle}" Foreground="#107C10"/>
                            <Border Background="#F5F5F5" CornerRadius="4" Padding="16" Margin="0,0,0,16">
                                <StackPanel>
                                    <TextBlock Text="Results" FontWeight="SemiBold" FontSize="14" Margin="0,0,0,8"/>
                                    <TextBlock Name="ResultSubsQueried"/>
                                    <TextBlock Name="ResultTotalRecords"/>
                                    <TextBlock Name="ResultDuration"/>
                                    <TextBlock Name="ResultFileSize"/>
                                    <TextBlock Name="ResultSecureScore" Foreground="#0078D4" FontWeight="SemiBold" Margin="0,8,0,0"/>
                                </StackPanel>
                            </Border>
                            <TextBlock Text="Output File:" FontWeight="SemiBold" Margin="0,0,0,4"/>
                            <TextBox Name="ResultFilePath" IsReadOnly="True" Padding="6,6" FontSize="12" Background="#F5F5F5" Margin="0,0,0,8"/>
                            <StackPanel Orientation="Horizontal" Margin="0,0,0,16">
                                <Button Name="BtnOpenFile" Content="Open File" Style="{StaticResource NavButton}" Margin="0,0,8,0"/>
                                <Button Name="BtnOpenFolder" Content="Open Folder" Style="{StaticResource NavButtonSecondary}"/>
                            </StackPanel>
                            <Border Name="ResultWarningPanel" Background="#FFF8E1" BorderBrush="#FFD54F" BorderThickness="1" CornerRadius="4" Padding="12" Visibility="Collapsed">
                                <StackPanel>
                                    <TextBlock FontWeight="SemiBold" Text="Subscription Warnings" Margin="0,0,0,6"/>
                                    <TextBlock Name="ResultWarningSummary" TextWrapping="Wrap" Margin="0,0,0,4"/>
                                    <TextBlock Name="ResultWarnings" TextWrapping="Wrap"/>
                                    <Expander Name="ResultWarningExpander" Header="Show details..." Visibility="Collapsed" Margin="0,6,0,0">
                                        <TextBlock Name="ResultWarningDetails" TextWrapping="Wrap" Margin="16,4,0,0" Foreground="#555"/>
                                    </Expander>
                                </StackPanel>
                            </Border>
                        </StackPanel>
                    </ScrollViewer>
                </TabItem>

                <!-- ═══ Step 8: Manual Export Reminder ═══ -->
                <TabItem>
                    <ScrollViewer VerticalScrollBarVisibility="Auto">
                        <StackPanel>
                            <TextBlock Text="Manual Exports Required" Style="{StaticResource SectionTitle}"/>
                            <TextBlock TextWrapping="Wrap" Foreground="#666" Margin="0,0,0,16"
                                       Text="The following data sources must be exported manually. They are not covered by this tool."/>

                            <Border Background="White" BorderBrush="#E0E0E0" BorderThickness="1" CornerRadius="4" Padding="16" Margin="0,0,0,12">
                                <StackPanel>
                                    <TextBlock FontWeight="SemiBold" FontSize="14" Text="1. Microsoft Defender XDR (Secure Score)" Margin="0,0,0,8"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="1. Navigate to: https://security.microsoft.com/securescore"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="2. Note the Secure Score value (screenshot) — share with Microsoft"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="3. Enter the score in the blue box below"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="4. Select the Recommended actions tab"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="5. Click Export to download the CSV report"/>
                                    <TextBlock Foreground="#666" FontStyle="Italic" Margin="0,8,0,0" Text="Required: Entra ID Global Reader"/>
                                </StackPanel>
                            </Border>

                            <Border Background="White" BorderBrush="#E0E0E0" BorderThickness="1" CornerRadius="4" Padding="16" Margin="0,0,0,16">
                                <StackPanel>
                                    <TextBlock FontWeight="SemiBold" FontSize="14" Text="2. Microsoft Purview (Compliance Manager)" Margin="0,0,0,8"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="1. Navigate to: https://purview.microsoft.com/compliancemanager/improvementactionspage"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="2. Ensure no filters are applied — all filter options must be set to Any"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,4" Text="3. Click Export actions to download ExportActions.xlsx"/>
                                    <TextBlock Foreground="#666" FontStyle="Italic" Margin="0,8,0,0" Text="Required: Compliance Manager Reader or Entra ID Global Reader"/>
                                </StackPanel>
                            </Border>

                            <Border Background="#E3F2FD" BorderBrush="#90CAF9" BorderThickness="1" CornerRadius="4" Padding="12">
                                <StackPanel>
                                    <TextBlock FontWeight="SemiBold" Text="Microsoft Secure Score" Margin="0,0,0,6"/>
                                    <TextBlock TextWrapping="Wrap" Margin="0,0,0,8" Text="Enter the Microsoft Secure Score value from the Defender XDR portal:"/>
                                    <StackPanel Orientation="Horizontal">
                                        <TextBox Name="TxtMsSecureScore" Width="100" Padding="6,4" FontSize="14" Margin="0,0,8,0"/>
                                        <TextBlock Text="%" VerticalAlignment="Center" FontSize="14"/>
                                    </StackPanel>
                                </StackPanel>
                            </Border>
                        </StackPanel>
                    </ScrollViewer>
                </TabItem>

                <!-- ═══ Step 9: Final Checklist ═══ -->
                <TabItem>
                    <ScrollViewer VerticalScrollBarVisibility="Auto">
                        <StackPanel>
                            <TextBlock Text="Final Checklist" Style="{StaticResource SectionTitle}"/>
                            <TextBlock TextWrapping="Wrap" Foreground="#666" Margin="0,0,0,16"
                                       Text="Review all items before sharing data with the Microsoft CSA."/>
                            <StackPanel Name="ChecklistPanel" Margin="0,0,0,16">
                                <CheckBox Name="ChkMDC" Content="Defender for Cloud — MDC Recommendations exported" FontSize="13" Margin="0,0,0,8"/>
                                <CheckBox Name="ChkMCSB" Content="Defender for Cloud — MCSB Compliance exported" FontSize="13" Margin="0,0,0,8"/>
                                <CheckBox Name="ChkXDR" Content="Microsoft Defender XDR — CSV exported (manual)" FontSize="13" Margin="0,0,0,8"/>
                                <CheckBox Name="ChkPurview" Content="Microsoft Purview — Excel exported (manual)" FontSize="13" Margin="0,0,0,8"/>
                                <CheckBox Name="ChkDfcScore" Content="Defender for Cloud Secure Score captured" FontSize="13" Margin="0,0,0,8"/>
                                <CheckBox Name="ChkMsScore" Content="Microsoft Secure Score captured" FontSize="13" Margin="0,0,0,8"/>
                            </StackPanel>
                            <Border Background="#F5F5F5" CornerRadius="4" Padding="16" Margin="0,0,0,16">
                                <StackPanel>
                                    <TextBlock Text="Export Statistics" FontWeight="SemiBold" FontSize="14" Margin="0,0,0,8"/>
                                    <TextBlock Name="StatsTotal"/>
                                    <TextBlock Name="StatsOk" Foreground="#107C10"/>
                                    <TextBlock Name="StatsPermission" Foreground="#D83B01"/>
                                    <TextBlock Name="StatsNotOnboarded" Foreground="#D83B01"/>
                                    <TextBlock Name="StatsDataGaps" Foreground="#D83B01" FontWeight="SemiBold" Margin="0,6,0,0"/>
                                </StackPanel>
                            </Border>
                            <StackPanel Orientation="Horizontal" Margin="0,0,0,8">
                                <Button Name="BtnSaveExportLog" Content="Export Log and Create ZIP" Style="{StaticResource NavButton}" Margin="0,0,8,0"/>
                                <Button Name="BtnOpenOutputFolder" Content="Open Output Folder" Style="{StaticResource NavButtonSecondary}"/>
                            </StackPanel>
                            <TextBlock Name="ReportStatus" Foreground="#107C10" Margin="0,0,0,8"/>

                            <Border Name="CsaRemediation" Background="#FFF8E1" BorderBrush="#FFD54F" BorderThickness="1" CornerRadius="4" Padding="12" Margin="0,8,0,0" Visibility="Collapsed">
                                <StackPanel>
                                    <TextBlock FontWeight="SemiBold" Text="Remediation Support Available" Margin="0,0,0,6"/>
                                    <TextBlock TextWrapping="Wrap" Text="If subscriptions are missing data due to Defender for Cloud not being onboarded, the involved CSA can support remediation of these gaps. If needed, an additional Technical Blocker Mitigation VBD for Defender for Cloud onboarding can be dispatched."/>
                                    <TextBlock TextWrapping="Wrap" FontWeight="SemiBold" Margin="0,10,0,0" Text="Options:"/>
                                    <TextBlock TextWrapping="Wrap" Text="  1. Proceed with the ESA based on the current data quality"/>
                                    <TextBlock TextWrapping="Wrap" Text="  2. Engage the CSA to remediate gaps before continuing"/>
                                </StackPanel>
                            </Border>
                        </StackPanel>
                    </ScrollViewer>
                </TabItem>
            </TabControl>

            <!-- Bottom navigation bar -->
            <Border Grid.Row="1" Background="#FAFAFA" BorderBrush="#E0E0E0" BorderThickness="0,1,0,0" Padding="24,12">
                <DockPanel>
                    <Button Name="BtnBack" Content="Back" DockPanel.Dock="Left" Style="{StaticResource NavButtonSecondary}"/>
                    <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" HorizontalAlignment="Right">
                        <Button Name="BtnNext" Content="Next" Style="{StaticResource NavButton}"/>
                    </StackPanel>
                    <TextBlock/>
                </DockPanel>
            </Border>
        </Grid>
    </Grid>
</Window>
"@

# ══════════════════════════════════════════════════════════════════════════════
# Load XAML and find controls
# ══════════════════════════════════════════════════════════════════════════════
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

# Helper to find named elements
function Find-Control { param([string]$Name) $window.FindName($Name) }

# Map all named controls
$wizardPages      = Find-Control "WizardPages"
$btnBack           = Find-Control "BtnBack"
$btnNext           = Find-Control "BtnNext"

# Step labels
$stepLabels = @()
for ($i = 0; $i -le 9; $i++) { $stepLabels += Find-Control "Step${i}Label" }

# Step 0: Prerequisites
$prereqPanel       = Find-Control "PrereqPanel"
$prereqMessage     = Find-Control "PrereqMessage"

# Step 1: Export Type
$radioMDC          = Find-Control "RadioMDC"
$radioMCSB         = Find-Control "RadioMCSB"
$radioBoth         = Find-Control "RadioBoth"

# Step 2: Sign In
$sessionInfoPanel  = Find-Control "SessionInfoPanel"
$noSessionPanel    = Find-Control "NoSessionPanel"
$sessionAccount    = Find-Control "SessionAccount"
$sessionTenant     = Find-Control "SessionTenant"
$btnUseSession     = Find-Control "BtnUseSession"
$btnReSignIn       = Find-Control "BtnReSignIn"
$btnSignIn         = Find-Control "BtnSignIn"
$signInStatus      = Find-Control "SignInStatus"

# Step 3: Tenant
$tenantList        = Find-Control "TenantList"
$tenantAutoSkip    = Find-Control "TenantAutoSkip"
$tenantSubtitle    = Find-Control "TenantSubtitle"

# Step 4: Subscriptions
$subFilter         = Find-Control "SubFilter"
$btnSelectAll      = Find-Control "BtnSelectAll"
$btnUnselectAll    = Find-Control "BtnUnselectAll"
$subCount          = Find-Control "SubCount"
$subList           = Find-Control "SubList"

# Step 5: Output
$txtOutputFolder   = Find-Control "TxtOutputFolder"
$btnBrowse         = Find-Control "BtnBrowse"
$txtOutputFile     = Find-Control "TxtOutputFile"
$summaryExportType = Find-Control "SummaryExportType"
$summaryTenant     = Find-Control "SummaryTenant"
$summarySubCount   = Find-Control "SummarySubCount"
$summaryOutput     = Find-Control "SummaryOutput"

# Step 6: Export Progress
$exportTitle       = Find-Control "ExportTitle"
$progressOverall   = Find-Control "ProgressOverall"
$progressOverallText = Find-Control "ProgressOverallText"
$progressCurrent   = Find-Control "ProgressCurrent"
$progressCurrentLabel = Find-Control "ProgressCurrentLabel"
$progressCurrentText = Find-Control "ProgressCurrentText"
$exportLog         = Find-Control "ExportLog"
$exportElapsed     = Find-Control "ExportElapsed"
$btnCancel         = Find-Control "BtnCancel"

# Step 7: Results
$resultTitle       = Find-Control "ResultTitle"
$resultSubsQueried = Find-Control "ResultSubsQueried"
$resultTotalRecords= Find-Control "ResultTotalRecords"
$resultDuration    = Find-Control "ResultDuration"
$resultFileSize    = Find-Control "ResultFileSize"
$resultSecureScore = Find-Control "ResultSecureScore"
$resultFilePath    = Find-Control "ResultFilePath"
$btnOpenFile       = Find-Control "BtnOpenFile"
$btnOpenFolder     = Find-Control "BtnOpenFolder"
$resultWarningPanel  = Find-Control "ResultWarningPanel"
$resultWarningSummary= Find-Control "ResultWarningSummary"
$resultWarnings      = Find-Control "ResultWarnings"
$resultWarningExpander = Find-Control "ResultWarningExpander"
$resultWarningDetails  = Find-Control "ResultWarningDetails"

# Step 8: Manual Exports
$txtMsSecureScore  = Find-Control "TxtMsSecureScore"

# Step 9: Final Checklist
$chkMDC            = Find-Control "ChkMDC"
$chkMCSB           = Find-Control "ChkMCSB"
$chkXDR            = Find-Control "ChkXDR"
$chkPurview        = Find-Control "ChkPurview"
$chkDfcScore       = Find-Control "ChkDfcScore"
$chkMsScore        = Find-Control "ChkMsScore"
$btnSaveExportLog  = Find-Control "BtnSaveExportLog"
$btnOpenOutputFolder = Find-Control "BtnOpenOutputFolder"
$reportStatus      = Find-Control "ReportStatus"
$statsTotal        = Find-Control "StatsTotal"
$statsOk           = Find-Control "StatsOk"
$statsPermission   = Find-Control "StatsPermission"
$statsNotOnboarded = Find-Control "StatsNotOnboarded"
$statsDataGaps     = Find-Control "StatsDataGaps"
$csaRemediation    = Find-Control "CsaRemediation"

# ══════════════════════════════════════════════════════════════════════════════
# State
# ══════════════════════════════════════════════════════════════════════════════
$script:currentStep     = 0
$script:azContext       = $null
$script:tenants         = @()
$script:selectedTenant  = $null
$script:subscriptions   = @()
$script:selectedSubs    = @()
$script:allSubCheckboxes = @()
$script:exportRunning   = $false
$script:exportCancelled = $false
$script:exportAppending = $false   # True when running second export in "Both" mode
$script:pendingSecondExport = $false  # True when MDC done, MCSB pending in "Both" mode
$script:exportSync      = $null   # Synchronized hashtable for background thread
$script:scriptDir       = $PSScriptRoot
$script:outputFolder    = $PSScriptRoot
$script:exportResults   = @{}      # Stores MDC and MCSB results across runs
$script:subStatuses     = @{}      # SubId -> { Status, Readiness, Detail }
$script:dfcHealthStatus = @{}      # SubId -> { Plans, EnabledCount, FreeCount, TotalPlans }
$script:dfcSecureScore  = $null
$script:msSecureScore   = $null
$script:failedSubs      = @()
$script:permissionFails = @()
$script:notOnboarded    = @()
$script:otherFails      = @()    # Non-permission, non-timeout failures
$script:totalRecordsExported = 0
$script:exportOutputFile = ""

# ══════════════════════════════════════════════════════════════════════════════
# Navigation
# ══════════════════════════════════════════════════════════════════════════════
function Update-StepLabels {
    for ($i = 0; $i -le 9; $i++) {
        if ($i -lt $script:currentStep) {
            $stepLabels[$i].Text = [char]0x2714 + " " + $stepLabels[$i].Text.TrimStart([char]0x2714, [char]0x25CF, ' ')
            $stepLabels[$i].Style = $window.FindResource("StepLabelDone")
        } elseif ($i -eq $script:currentStep) {
            $stepLabels[$i].Text = $stepLabels[$i].Text.TrimStart([char]0x2714, [char]0x25CF, ' ')
            $stepLabels[$i].Style = $window.FindResource("StepLabelActive")
        } else {
            $stepLabels[$i].Text = $stepLabels[$i].Text.TrimStart([char]0x2714, [char]0x25CF, ' ')
            $stepLabels[$i].Style = $window.FindResource("StepLabel")
        }
    }
}

function Set-WizardStep {
    param([int]$Step)
    $script:currentStep = $Step
    $wizardPages.SelectedIndex = $Step
    Update-StepLabels

    # Nav button visibility
    $btnBack.Visibility = if ($Step -eq 0 -or $Step -eq 6) { "Collapsed" } else { "Visible" }

    switch ($Step) {
        0 { $btnNext.Content = "Next"; $btnNext.IsEnabled = $script:prereqPassed; $btnNext.Visibility = "Visible" }
        1 { $btnNext.Content = "Next"; $btnNext.IsEnabled = $true; $btnNext.Visibility = "Visible" }
        2 { $btnNext.Content = "Next"; $btnNext.IsEnabled = ($null -ne $script:azContext); $btnNext.Visibility = "Visible" }
        3 { $btnNext.Content = "Next"; $btnNext.IsEnabled = ($tenantList.SelectedIndex -ge 0); $btnNext.Visibility = "Visible" }
        4 { $btnNext.Content = "Next"; Update-SubNextButton; $btnNext.Visibility = "Visible" }
        5 { $btnNext.Content = "Start Export"; $btnNext.IsEnabled = $true; $btnNext.Visibility = "Visible" }
        6 { $btnNext.Visibility = "Collapsed" }
        7 { $btnNext.Content = "Next"; $btnNext.IsEnabled = $true; $btnNext.Visibility = "Visible" }
        8 { $btnNext.Content = "Next"; $btnNext.IsEnabled = $true; $btnNext.Visibility = "Visible" }
        9 { $btnNext.Content = "Close"; $btnNext.IsEnabled = $true; $btnNext.Visibility = "Visible" }
    }
}

function Update-SubNextButton {
    $checked = @($script:allSubCheckboxes | Where-Object { $_.IsChecked -eq $true })
    $btnNext.IsEnabled = ($checked.Count -gt 0)
}

# ══════════════════════════════════════════════════════════════════════════════
# Step 0: Prerequisites Check
# ══════════════════════════════════════════════════════════════════════════════
$script:prereqPassed = $false

function Test-Prerequisites {
    $prereqPanel.Children.Clear()
    $allPass = $true

    $checks = @(
        @{ Name = "PowerShell 7.x"; Pass = ($PSVersionTable.PSVersion.Major -ge 7) },
        @{ Name = "Az.Accounts module"; Pass = ($null -ne (Get-Module -ListAvailable -Name Az.Accounts)) },
        @{ Name = "Az.ResourceGraph module"; Pass = ($null -ne (Get-Module -ListAvailable -Name Az.ResourceGraph)) },
        @{ Name = "Non-admin execution"; Pass = (-not $isAdmin) },
        @{ Name = "FullLanguage mode"; Pass = ($ExecutionContext.SessionState.LanguageMode -eq "FullLanguage") },
        @{ Name = "Not Azure Cloud Shell"; Pass = (-not ($env:AZUREPS_HOST_ENVIRONMENT -match 'cloud-shell' -or $env:ACC_CLOUD -eq 'true')) }
    )

    foreach ($check in $checks) {
        $icon = if ($check.Pass) { [char]0x2705 } else { [char]0x274C }
        $color = if ($check.Pass) { "#107C10" } else { "#D83B01" }
        $tb = New-Object System.Windows.Controls.TextBlock
        $tb.Text = "$icon  $($check.Name)"
        $tb.FontSize = 14
        $tb.Margin = [System.Windows.Thickness]::new(0, 4, 0, 4)
        $tb.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
        $prereqPanel.Children.Add($tb) | Out-Null

        if (-not $check.Pass) { $allPass = $false }
    }

    if (-not $allPass) {
        $prereqMessage.Text = "Some prerequisites are not met. Please resolve the issues above before continuing."
        $prereqMessage.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#D83B01")

        $missing = @($checks | Where-Object { -not $_.Pass -and $_.Name -match "module" } | ForEach-Object { $_.Name -replace ' module', '' })
        if ($missing.Count -gt 0) {
            $prereqMessage.Text += "`n`nInstall missing modules:`n  Install-Module $($missing -join ', ') -Force"
        }
    } else {
        $prereqMessage.Text = "All prerequisites met."
        $prereqMessage.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#107C10")
    }

    $script:prereqPassed = $allPass
    $btnNext.IsEnabled = $allPass
}

# ══════════════════════════════════════════════════════════════════════════════
# Step 2: Sign In
# ══════════════════════════════════════════════════════════════════════════════
function Initialize-SignInStep {
    Update-AzConfig -LoginExperienceV2 Off -DisplayBreakingChangeWarning $false -WarningAction SilentlyContinue -ErrorAction SilentlyContinue *>$null

    $ctx = Get-AzContext
    if ($ctx) {
        $tenantName = ""
        try { $tenantName = (Get-AzTenant | Where-Object { $_.Id -eq $ctx.Tenant.Id } | Select-Object -ExpandProperty Name) } catch {}
        $sessionAccount.Text = "Account: $($ctx.Account)"
        $sessionTenant.Text = "Tenant: $tenantName ($($ctx.Tenant.Id))"
        $sessionInfoPanel.Visibility = "Visible"
        $noSessionPanel.Visibility = "Collapsed"
        $script:azContext = $ctx
    } else {
        $sessionInfoPanel.Visibility = "Collapsed"
        $noSessionPanel.Visibility = "Visible"
    }
    $signInStatus.Text = ""
}

function Invoke-AzureSignIn {
    param([string]$TenantId)
    $signInStatus.Text = "Signing in to Azure..."
    $signInStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#666666")
    $window.Cursor = [System.Windows.Input.Cursors]::Wait
    try {
        if ($TenantId) {
            $script:azContext = Connect-AzAccount -TenantId $TenantId -WarningAction SilentlyContinue -ErrorAction Stop
        } else {
            $script:azContext = Connect-AzAccount -WarningAction SilentlyContinue -ErrorAction Stop
        }
        # Refresh session info panel with new account details
        $ctx = Get-AzContext
        $tenantName = ""
        try { $tenantName = (Get-AzTenant | Where-Object { $_.Id -eq $ctx.Tenant.Id } | Select-Object -ExpandProperty Name) } catch {}
        $sessionAccount.Text = "Account: $($ctx.Account)"
        $sessionTenant.Text = "Tenant: $tenantName ($($ctx.Tenant.Id))"
        $sessionInfoPanel.Visibility = "Visible"
        $noSessionPanel.Visibility = "Collapsed"
        $signInStatus.Text = ""
        $btnNext.IsEnabled = $true
    } catch {
        $signInStatus.Text = "Sign-in failed: $($_.Exception.Message)"
        $signInStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#D83B01")
    } finally {
        $window.Cursor = $null
    }
}

$btnSignIn.Add_Click({ Invoke-AzureSignIn })
$btnReSignIn.Add_Click({
    Disconnect-AzAccount -ErrorAction SilentlyContinue *>$null
    Clear-AzContext -Scope Process -Force -ErrorAction SilentlyContinue *>$null
    $script:azContext = $null
    Invoke-AzureSignIn
})
$btnUseSession.Add_Click({
    $signInStatus.Text = "Validating session..."
    try {
        $token = Get-AzAccessToken -ResourceUrl "https://management.azure.com" -TenantId $script:azContext.Tenant.Id -ErrorAction Stop
        if ($token) {
            $signInStatus.Text = "Session valid."
            $signInStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#107C10")
            $btnNext.IsEnabled = $true
        }
    } catch {
        $signInStatus.Text = "Session expired. Please re-sign in."
        $signInStatus.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#D83B01")
        $script:azContext = $null
        $btnNext.IsEnabled = $false
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Step 3: Tenant Selection
# ══════════════════════════════════════════════════════════════════════════════
function Initialize-TenantStep {
    $tenantList.Items.Clear()
    $window.Cursor = [System.Windows.Input.Cursors]::Wait
    try {
        $script:tenants = @(Get-AzTenant | Select-Object Id, Name)
    } catch {
        $script:tenants = @()
    }
    $window.Cursor = $null

    if ($script:tenants.Count -eq 1) {
        $script:selectedTenant = $script:tenants[0]
        $tenantList.Items.Add("$($script:tenants[0].Name) ($($script:tenants[0].Id))") | Out-Null
        $tenantList.SelectedIndex = 0
        $tenantAutoSkip.Visibility = "Visible"
        $tenantSubtitle.Text = "Only one tenant available — auto-selected."
    } elseif ($script:tenants.Count -gt 1) {
        $tenantAutoSkip.Visibility = "Collapsed"
        $tenantSubtitle.Text = "Your account has access to multiple tenants. Select one:"
        foreach ($t in $script:tenants) {
            $tenantList.Items.Add("$($t.Name) ($($t.Id))") | Out-Null
        }
        # Pre-select current tenant
        $currentTenantId = $script:azContext.Tenant.Id
        for ($i = 0; $i -lt $script:tenants.Count; $i++) {
            if ($script:tenants[$i].Id -eq $currentTenantId) {
                $tenantList.SelectedIndex = $i
                break
            }
        }
    }
}

$tenantList.Add_SelectionChanged({
    if ($tenantList.SelectedIndex -ge 0) {
        $script:selectedTenant = $script:tenants[$tenantList.SelectedIndex]
        $btnNext.IsEnabled = $true
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Step 4: Subscriptions
# ══════════════════════════════════════════════════════════════════════════════
function Initialize-SubscriptionStep {
    $subList.Items.Clear()
    $script:allSubCheckboxes = @()
    $window.Cursor = [System.Windows.Input.Cursors]::Wait

    try {
        $tenantId = $script:selectedTenant.Id

        # Re-auth to selected tenant if different from current context
        $currentCtx = Get-AzContext
        if ($currentCtx.Tenant.Id -ne $tenantId) {
            $script:azContext = Connect-AzAccount -TenantId $tenantId -WarningAction SilentlyContinue -ErrorAction Stop
        }

        $script:subscriptions = @(Get-AzSubscription -TenantId $tenantId | Select-Object Id, Name, State)
    } catch {
        $script:subscriptions = @()
    }

    # ── Active DfC health check: query Defender pricing tiers via ARG ──
    $script:dfcHealthStatus = @{}
    if ($script:subscriptions.Count -gt 0) {
        try {
            $allSubIds = $script:subscriptions | ForEach-Object { $_.Id }
            $dfcQuery = @"
securityresources
| where type == "microsoft.security/pricings"
| project subscriptionId, planName = name, pricingTier = tostring(properties.pricingTier)
"@
            $dfcResults = [System.Collections.Generic.List[object]]::new()
            # ARG allows max 1000 subs per query; batch in groups of 200 and page results
            for ($b = 0; $b -lt $allSubIds.Count; $b += 200) {
                $batch = $allSubIds[$b..([math]::Min($b + 199, $allSubIds.Count - 1))]
                $argSkip = 0; $argPage = 1000
                while ($true) {
                    $batchResults = if ($argSkip -eq 0) {
                        Search-AzGraph -Query $dfcQuery -Subscription $batch -First $argPage -ErrorAction SilentlyContinue
                    } else {
                        Search-AzGraph -Query $dfcQuery -Subscription $batch -First $argPage -Skip $argSkip -ErrorAction SilentlyContinue
                    }
                    if (-not $batchResults -or $batchResults.Count -eq 0) { break }
                    foreach ($r in $batchResults) { $dfcResults.Add($r) }
                    if ($batchResults.Count -lt $argPage) { break }
                    $argSkip += $argPage
                }
            }
            # Group by subscription
            $grouped = $dfcResults | Group-Object subscriptionId
            foreach ($g in $grouped) {
                $plans = $g.Group
                $enabledCount = @($plans | Where-Object { $_.pricingTier -eq 'Standard' }).Count
                $freeCount = @($plans | Where-Object { $_.pricingTier -eq 'Free' }).Count
                $script:dfcHealthStatus[$g.Name] = @{
                    Plans = $plans; EnabledCount = $enabledCount
                    FreeCount = $freeCount; TotalPlans = $plans.Count
                }
            }
            # Mark subscriptions with no pricing data at all
            foreach ($sub in $script:subscriptions) {
                if (-not $script:dfcHealthStatus.ContainsKey($sub.Id)) {
                    $script:dfcHealthStatus[$sub.Id] = @{ Plans = @(); EnabledCount = 0; FreeCount = 0; TotalPlans = 0 }
                }
            }
        } catch {
            # If health check fails, continue without it — icons will be absent
        }
    }

    $window.Cursor = $null

    $subCount.Text = "$($script:subscriptions.Count) subscriptions found"
    Populate-SubscriptionList ""
}

$script:suppressSubEvents = $false

function Populate-SubscriptionList {
    param([string]$Filter)
    $subList.Items.Clear()
    $script:allSubCheckboxes = [System.Collections.Generic.List[System.Windows.Controls.CheckBox]]::new()

    foreach ($sub in $script:subscriptions) {
        if ($Filter -and $sub.Name -notmatch [regex]::Escape($Filter) -and $sub.Id -notmatch [regex]::Escape($Filter)) { continue }

        # Build DfC status indicator from active health check
        $health = $script:dfcHealthStatus[$sub.Id]
        $statusIcon = ""
        $statusTip = ""
        if ($health -and $health.TotalPlans -gt 0) {
            if ($health.FreeCount -eq 0) {
                $statusIcon = [char]0x2705  # green check — all plans Standard
                $statusTip = "Fully onboarded ($($health.EnabledCount) plans on Standard tier)"
            } elseif ($health.EnabledCount -gt 0) {
                $statusIcon = [char]0x26A0  # yellow warning — mixed
                $freePlans = @($health.Plans | Where-Object { $_.pricingTier -eq 'Free' } | ForEach-Object { $_.planName }) -join ', '
                $statusTip = "Partially onboarded — Free tier (foundational CSPM only): $freePlans"
            } else {
                $statusIcon = [char]0x26A0  # yellow warning — all Free
                $statusTip = "Foundational CSPM only (all plans on Free tier)"
            }
        } elseif ($health) {
            $statusIcon = [char]0x26A0
            $statusTip = "Foundational CSPM only (no Defender plans configured)"
        }

        $cb = New-Object System.Windows.Controls.CheckBox
        $displayText = if ($statusIcon) { "$statusIcon  $($sub.Name) ($($sub.Id))" } else { "$($sub.Name) ($($sub.Id))" }
        $cb.Content = $displayText
        $cb.ToolTip = $statusTip
        $cb.Tag = $sub.Id
        $cb.FontSize = 13
        $cb.Margin = [System.Windows.Thickness]::new(0, 3, 0, 3)
        $cb.IsChecked = $false
        $cb.Add_Checked({ if (-not $script:suppressSubEvents) { Update-SubNextButton } })
        $cb.Add_Unchecked({ if (-not $script:suppressSubEvents) { Update-SubNextButton } })
        $subList.Items.Add($cb) | Out-Null
        $script:allSubCheckboxes.Add($cb)
    }
    Update-SubCount
    Update-SubNextButton
}

function Update-SubCount {
    $checked = @($script:allSubCheckboxes | Where-Object { $_.IsChecked -eq $true })
    $subCount.Text = "$($checked.Count) of $($script:subscriptions.Count) selected"
}

$subFilter.Add_TextChanged({
    Populate-SubscriptionList $subFilter.Text
})

$btnSelectAll.Add_Click({
    $script:suppressSubEvents = $true
    foreach ($cb in $script:allSubCheckboxes) { $cb.IsChecked = $true }
    $script:suppressSubEvents = $false
    Update-SubCount
    Update-SubNextButton
})
$btnUnselectAll.Add_Click({
    $script:suppressSubEvents = $true
    foreach ($cb in $script:allSubCheckboxes) { $cb.IsChecked = $false }
    $script:suppressSubEvents = $false
    Update-SubCount
    Update-SubNextButton
})

# ══════════════════════════════════════════════════════════════════════════════
# Step 5: Output Settings
# ══════════════════════════════════════════════════════════════════════════════
function Initialize-OutputStep {
    $txtOutputFolder.Text = $script:outputFolder

    if ($radioBoth.IsChecked) {
        $txtOutputFile.Text = "Export_MDC_Recommendations_*.csv + Export_MCSB_Compliance_*.csv"
        $summaryExportType.Text = "Export: MDC Recommendations + MCSB Compliance"
    } else {
        $exportType = if ($radioMDC.IsChecked) { "MDC" } else { "MCSB" }
        $paramFile = if ($exportType -eq "MDC") { "MDC_Params.json" } else { "MCSB_Params.json" }
        $paramPath = Join-Path $script:scriptDir $paramFile
        $params = Get-Content -Path $paramPath | ConvertFrom-Json
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension($params.CSVFileName)
        $ext = [System.IO.Path]::GetExtension($params.CSVFileName)
        $ts = Get-Date -Format "yyyyMMdd_HHmmss"
        $txtOutputFile.Text = "${baseName}_${ts}${ext}"
        $summaryExportType.Text = "Export: $exportType Recommendations"
    }

    $summaryTenant.Text = "Tenant: $($script:selectedTenant.Name)"
    $selectedSubs = @($script:allSubCheckboxes | Where-Object { $_.IsChecked -eq $true })
    $summarySubCount.Text = "Subscriptions: $($selectedSubs.Count) selected"
    $summaryOutput.Text = "Output: $($script:outputFolder)\"
}

$btnBrowse.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.SelectedPath = $script:outputFolder
    $dialog.Description = "Select output folder for exported CSV files"
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:outputFolder = $dialog.SelectedPath
        $txtOutputFolder.Text = $script:outputFolder
        $summaryOutput.Text = "Output: $($script:outputFolder)\"
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Step 6: Export Execution (async — runs in background thread)
# ══════════════════════════════════════════════════════════════════════════════

function Complete-Export {
    $sync = $script:pollSync
    $exportType = $sync.ExportType
    $selectedSubIds = $sync.SubIds

    # Copy results to script state
    if ($sync.SecureScore) { $script:dfcSecureScore = $sync.SecureScore }
    $script:failedSubs = if ($sync.FailedSubs) { @($sync.FailedSubs.ToArray()) } else { @() }
    $script:permissionFails = if ($sync.PermFails) { @($sync.PermFails.ToArray()) } else { @() }
    $script:notOnboarded = if ($sync.NotOnboarded) { @($sync.NotOnboarded.ToArray()) } else { @() }
    $script:otherFails = if ($sync.OtherFails) { @($sync.OtherFails.ToArray()) } else { @() }
    $script:totalRecordsExported = $sync.TotalRecords
    $script:exportOutputFile = $sync.OutputFile

    if ($null -eq $script:subStatuses) { $script:subStatuses = @{} }
    if ($sync.SubStatuses) {
        $syncKeys = @($sync.SubStatuses.Keys)
        foreach ($key in $syncKeys) {
            $script:subStatuses[$key] = $sync.SubStatuses[$key]
        }
    }

    $failedCount = if ($sync.FailedSubs) { $sync.FailedSubs.Count } else { 0 }
    $script:exportResults[$exportType] = @{
        SubsQueried     = $selectedSubIds.Count
        SubsOk          = $selectedSubIds.Count - $failedCount
        SubsFailed      = $failedCount
        TotalRecords    = $sync.TotalRecords
        OutputFile      = $sync.OutputFile
        FileSize        = $sync.FileSize
        Duration        = $sync.Duration
        SecureScore     = $sync.SecureScore
        PermissionFails = if ($sync.PermFails) { $sync.PermFails.Count } else { 0 }
        NotOnboarded    = if ($sync.NotOnboarded) { $sync.NotOnboarded.Count } else { 0 }
        OtherFails      = if ($sync.OtherFails) { $sync.OtherFails.Count } else { 0 }
    }

    try { $script:exportPS.Dispose() } catch {}
    $script:exportRunning = $false

    # Handle "Both" mode chaining
    if ($script:pendingSecondExport -and -not $sync.Cancel) {
        $script:pendingSecondExport = $false
        $script:exportAppending = $true
        $ts2 = Get-Date -Format "HH:mm:ss"
        $exportLog.AppendText("`r`n$ts2  ════════════════════════════════════════════`r`n")
        $exportLog.AppendText("$ts2  Starting MCSB export...`r`n")
        $exportLog.AppendText("$ts2  ════════════════════════════════════════════`r`n`r`n")
        $exportLog.ScrollToEnd()
        Start-Export -ExportType "MCSB"
    } else {
        $script:exportAppending = $false
        $script:pendingSecondExport = $false
        Initialize-ResultsStep
        Set-WizardStep 7
    }
}

function Start-Export {
    param([string]$ExportType)

    $script:exportRunning = $true
    $script:exportCancelled = $false
    if (-not $script:exportAppending) { $exportLog.Text = "" }
    $progressOverall.Value = 0
    $progressCurrent.Value = 0

    $exportType = $ExportType
    $paramFile = if ($exportType -eq "MDC") { "MDC_Params.json" } else { "MCSB_Params.json" }
    $paramPath = Join-Path $script:scriptDir $paramFile
    $params = Get-Content -Path $paramPath | ConvertFrom-Json
    $kqlQuery = Get-Content -Path (Join-Path $script:scriptDir $params.QueryFile) -Raw -Encoding UTF8
    $selectedSubIds = @($script:allSubCheckboxes | Where-Object { $_.IsChecked -eq $true } | ForEach-Object { $_.Tag })
    $script:selectedSubs = $selectedSubIds

    # Build subscription name lookup for background thread
    $subNameMap = @{}
    foreach ($sub in $script:subscriptions) { $subNameMap[$sub.Id] = $sub.Name }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($params.CSVFileName)
    $ext = [System.IO.Path]::GetExtension($params.CSVFileName)
    $tempFile = Join-Path $script:outputFolder "${baseName}_${timestamp}.incomplete"
    $finalFile = Join-Path $script:outputFolder "${baseName}_${timestamp}${ext}"
    $failedFile = Join-Path $script:outputFolder "${baseName}_${timestamp}.failed"

    Get-ChildItem -Path $script:outputFolder -Filter "*.incomplete" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue

    $startTime = Get-Date

    # Synchronized state for communication between background thread and UI
    $sync = [hashtable]::Synchronized(@{
        Cancel       = $false
        LogQueue     = [System.Collections.Concurrent.ConcurrentQueue[string]]::new()
        OverallPct   = 0
        OverallText  = ""
        CurrentLabel = ""
        CurrentPct   = 0
        CurrentText  = ""
        Status       = "running"
        # Metadata for Complete-Export
        ExportType   = $exportType
        SubIds       = $selectedSubIds
        # Results populated by background thread
        TotalRecords = 0
        OutputFile   = ""
        FileSize     = "N/A"
        Duration     = ""
        SecureScore  = $null
        FailedSubs   = [System.Collections.Concurrent.ConcurrentBag[hashtable]]::new()
        PermFails    = [System.Collections.Concurrent.ConcurrentBag[hashtable]]::new()
        NotOnboarded = [System.Collections.Concurrent.ConcurrentBag[hashtable]]::new()
        OtherFails   = [System.Collections.Concurrent.ConcurrentBag[hashtable]]::new()
        SubStatuses  = [hashtable]::Synchronized(@{})
    })
    $script:exportSync = $sync

    # ── Background export scriptblock ──
    $exportWork = {
        param($Sync, $KqlQuery, $SubIds, $SubNameMap, $TempFile, $FinalFile, $FailedFile, $ExportType, $StartTime, $DfcHealth)

        Import-Module Az.ResourceGraph -ErrorAction SilentlyContinue

        $pageSize = 1000
        $subCount = 0
        $totalSubs = $SubIds.Count
        $secureScoresList = [System.Collections.Generic.List[double]]::new()
        $totalRecordsExported = 0

        $Sync.LogQueue.Enqueue("Starting $ExportType export for $totalSubs subscriptions...")

        try {
            foreach ($subId in $SubIds) {
                if ($Sync.Cancel) { $Sync.LogQueue.Enqueue("Export cancelled by user."); break }

                $subCount++
                $subName = if ($SubNameMap[$subId]) { $SubNameMap[$subId] } else { $subId }
                $Sync.OverallPct = [math]::Round(($subCount - 1) / $totalSubs * 100)
                $Sync.OverallText = "$subCount / $totalSubs subscriptions"
                $Sync.CurrentLabel = "Current: $subName ($subId)"
                $Sync.CurrentPct = 0; $Sync.CurrentText = ""
                $Sync.LogQueue.Enqueue("Querying subscription ($subCount/$totalSubs): $subName")

                # Secure Score query (always)
                try {
                    $ssQ = "securityresources | where type == 'microsoft.security/securescores' | where properties.environment == 'Azure' | extend subscriptionSecureScore = round(100 * bin((todouble(properties.score.current))/ todouble(properties.score.max), 0.001)) | where subscriptionSecureScore > 0 | project subscriptionSecureScore, subscriptionId"
                    $ssR = Search-AzGraph -Query $ssQ -Subscription $subId -First 1 -ErrorAction Stop
                    if ($ssR -and $ssR.subscriptionSecureScore) { $secureScoresList.Add([double]$ssR.subscriptionSecureScore) }
                } catch { }

                # Total record count
                $totalRecords = 0
                try {
                    $trR = Search-AzGraph -Query "$KqlQuery | summarize totalRecords = count()" -Subscription $subId -First 1 -ErrorAction Stop
                    $totalRecords = if ($trR.totalRecords) { $trR.totalRecords } else { 0 }
                } catch { }

                $retrievedRecords = 0; $skip = 0; $subFailed = $false

                while ($true) {
                    if ($Sync.Cancel) { break }
                    $retryCount = 0; $maxRetries = 3; $retryDelay = 2; $queryResults = $null

                    while ($retryCount -le $maxRetries) {
                        try {
                            $queryResults = if ($skip -eq 0) {
                                Search-AzGraph -Query $KqlQuery -Subscription $subId -First $pageSize -ErrorAction Stop
                            } else {
                                Search-AzGraph -Query $KqlQuery -Subscription $subId -First $pageSize -Skip $skip -ErrorAction Stop
                            }
                            break
                        } catch {
                            $errorMsg = $_.Exception.Message
                            $errorCode = "Unknown"
                            try { $raw = $_.Exception.Response.Content; if ($raw) { $d = $raw | ConvertFrom-Json; if ($d.error.code) { $errorCode = $d.error.code } } } catch {}

                            if ($errorCode -eq "GatewayTimeout" -or $errorCode -eq "InternalServerError") {
                                $retryCount++
                                if ($retryCount -gt $maxRetries) {
                                    $Sync.LogQueue.Enqueue("  FAILED after $maxRetries retries: $errorCode")
                                    $Sync.FailedSubs.Add(@{ Id = $subId; Name = $subName; Error = $errorMsg })
                                    $Sync.OtherFails.Add(@{ Id = $subId; Name = $subName; Error = $errorMsg })
                                    $Sync.SubStatuses[$subId] = @{ Status = "Failed"; Readiness = "Other error"; Detail = $errorMsg }
                                    Add-Content -Path $FailedFile -Value "Subscription ID: $subId - Error: $errorMsg"
                                    $subFailed = $true; break
                                }
                                $backoff = [math]::Pow(2, $retryCount) * $retryDelay
                                $Sync.LogQueue.Enqueue("  Retry $retryCount/$maxRetries ($errorCode) - waiting ${backoff}s...")
                                Start-Sleep -Seconds $backoff
                            } else {
                                $Sync.LogQueue.Enqueue("  ERROR: $errorMsg")
                                $Sync.FailedSubs.Add(@{ Id = $subId; Name = $subName; Error = $errorMsg })
                                if ($errorMsg -match 'AuthorizationFailed|does not have authorization|Forbidden|AccessDenied') {
                                    $Sync.PermFails.Add(@{ Id = $subId; Name = $subName })
                                    $Sync.SubStatuses[$subId] = @{ Status = "Failed"; Readiness = "Missing permissions"; Detail = $errorMsg }
                                } else {
                                    $Sync.OtherFails.Add(@{ Id = $subId; Name = $subName; Error = $errorMsg })
                                    $Sync.SubStatuses[$subId] = @{ Status = "Failed"; Readiness = "Other error"; Detail = $errorMsg }
                                }
                                Add-Content -Path $FailedFile -Value "Subscription ID: $subId - Error: $errorMsg"
                                $subFailed = $true; break
                            }
                        }
                    }

                    if ($subFailed -or $null -eq $queryResults -or $queryResults.Count -eq 0) {
                        if (-not $subFailed) {
                            $Sync.LogQueue.Enqueue("  $subName - 0 records")
                            if ($totalRecords -eq 0) {
                                # Cross-reference with pre-export DfC health check to verify status
                                $health = if ($DfcHealth) { $DfcHealth[$subId] } else { $null }
                                if ($health -and $health.TotalPlans -gt 0 -and $health.EnabledCount -gt 0) {
                                    # Verified: DfC onboarded (Standard plans) but no data — no assessable resources
                                    $Sync.SubStatuses[$subId] = @{ Status = "OK"; Readiness = "No resources"; Detail = "DfC onboarded but no data returned" }
                                    $Sync.LogQueue.Enqueue("  $subName - DfC onboarded, no resources to assess")
                                } elseif ($health -and $health.TotalPlans -gt 0 -and $health.FreeCount -gt 0) {
                                    # Verified: plans exist but all Free tier = Foundational CSPM only
                                    $Sync.NotOnboarded.Add(@{ Id = $subId; Name = $subName })
                                    $Sync.SubStatuses[$subId] = @{ Status = "Yellow"; Readiness = "Foundational CSPM only"; Detail = "All Defender plans on Free tier" }
                                    $Sync.LogQueue.Enqueue("  $subName - Foundational CSPM only (all plans Free tier)")
                                } else {
                                    # Verified: no pricing data = Foundational CSPM only (no Defender plans configured)
                                    $Sync.NotOnboarded.Add(@{ Id = $subId; Name = $subName })
                                    $Sync.SubStatuses[$subId] = @{ Status = "Yellow"; Readiness = "Foundational CSPM only"; Detail = "No Defender plans configured" }
                                    $Sync.LogQueue.Enqueue("  $subName - Foundational CSPM only (no Defender plans configured)")
                                }
                            } else {
                                $Sync.SubStatuses[$subId] = @{ Status = "OK"; Readiness = "Fully onboarded"; Detail = "" }
                            }
                        }
                        break
                    }

                    $queryResults | ForEach-Object {
                        $_.PSObject.Properties | Where-Object { $_.Value -is [datetime] } | ForEach-Object { $_.Value = $_.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ") }
                        $_
                    } | Export-Csv -Path $TempFile -NoTypeInformation -Append

                    $retrievedRecords += $queryResults.Count; $skip += $pageSize
                    $remaining = [math]::Max(0, $totalRecords - $retrievedRecords)
                    $Sync.CurrentPct = if ($totalRecords -gt 0) { [math]::Min(100, [math]::Round($retrievedRecords / $totalRecords * 100)) } else { 100 }
                    $Sync.CurrentText = "$retrievedRecords / $totalRecords records"
                    $Sync.LogQueue.Enqueue("  $subName - $($queryResults.Count) records (remaining: $remaining)")

                    if ($queryResults.Count -lt $pageSize) {
                        $Sync.SubStatuses[$subId] = @{ Status = "OK"; Readiness = "Fully onboarded"; Detail = "" }
                        break
                    }
                    $queryResults = $null
                }
                $totalRecordsExported += $retrievedRecords
            }

            $Sync.OverallPct = 100
            $Sync.OverallText = "$totalSubs / $totalSubs subscriptions"
            $Sync.TotalRecords = $totalRecordsExported

            if ($secureScoresList.Count -gt 0) {
                $Sync.SecureScore = [math]::Round(($secureScoresList | Measure-Object -Average).Average, 2)
                $Sync.LogQueue.Enqueue("")
                $Sync.LogQueue.Enqueue("Overall Secure Score across $($secureScoresList.Count) subscriptions: $($Sync.SecureScore)")
            } else {
                $Sync.LogQueue.Enqueue("")
                $Sync.LogQueue.Enqueue("No Secure Score data found. This typically means Defender for Cloud is not onboarded on the selected subscriptions.")
            }

            if (Test-Path $TempFile) {
                Rename-Item -Path $TempFile -NewName (Split-Path $FinalFile -Leaf)
                $Sync.OutputFile = $FinalFile
                $fSize = (Get-Item $FinalFile).Length
                $units = @("KB", "MB", "GB"); $thr = @(1KB, 1MB, 1GB)
                $idx = ($thr | Where-Object { $fSize -ge $_ } | Measure-Object).Count - 1; if ($idx -lt 0) { $idx = 0 }
                $Sync.FileSize = "{0:N2} {1}" -f ($fSize / $thr[$idx]), $units[$idx]
                $Sync.LogQueue.Enqueue(""); $Sync.LogQueue.Enqueue("Export completed: $(Split-Path $FinalFile -Leaf) ($($Sync.FileSize))")
            } else {
                $Sync.LogQueue.Enqueue("Warning: No data was exported.")
            }

            $duration = (Get-Date) - $StartTime
            $Sync.Duration = "{0}h {1:D2}m {2:D2}s" -f $duration.Hours, $duration.Minutes, $duration.Seconds
            $Sync.LogQueue.Enqueue("Duration: $($Sync.Duration)")
        } catch {
            $Sync.LogQueue.Enqueue("Error: $($_.Exception.Message)")
        }
        $Sync.Status = "completed"
    }

    # Launch background PowerShell instance
    $ps = [powershell]::Create()
    $ps.AddScript($exportWork).AddArgument($sync).AddArgument($kqlQuery).AddArgument($selectedSubIds).AddArgument($subNameMap).AddArgument($tempFile).AddArgument($finalFile).AddArgument($failedFile).AddArgument($exportType).AddArgument($startTime).AddArgument($script:dfcHealthStatus) | Out-Null
    $script:exportPS = $ps
    $script:exportHandle = $ps.BeginInvoke()

    # Store references for the poll timer tick handler
    $script:pollSync = $sync
    $script:pollStartTime = $startTime

    $script:pollTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:pollTimer.Interval = [TimeSpan]::FromMilliseconds(200)
    $script:pollTimer.Add_Tick({
        $s = $script:pollSync
        # Drain log queue
        $msg = $null
        while ($s.LogQueue.TryDequeue([ref]$msg)) {
            $ts = Get-Date -Format "HH:mm:ss"
            $exportLog.AppendText("$ts  $msg`r`n")
            $exportLog.ScrollToEnd()
        }
        # Update progress
        $progressOverall.Value = $s.OverallPct
        $progressOverallText.Text = $s.OverallText
        $progressCurrentLabel.Text = $s.CurrentLabel
        $progressCurrent.Value = $s.CurrentPct
        $progressCurrentText.Text = $s.CurrentText
        # Elapsed
        $elapsed = (Get-Date) - $script:pollStartTime
        $exportElapsed.Text = "Elapsed: {0:D2}:{1:D2}:{2:D2}" -f $elapsed.Hours, $elapsed.Minutes, $elapsed.Seconds

        # Check completion
        if ($s.Status -ne "running") {
            $script:pollTimer.Stop()
            Complete-Export
        }
    })
    $script:pollTimer.Start()
}

function Start-ExportSequence {
    if ($radioBoth.IsChecked) {
        $exportTitle.Text = "Exporting MDC + MCSB..."
        $script:exportAppending = $false
        $script:pendingSecondExport = $true
        Start-Export -ExportType "MDC"
    } else {
        $exportTitle.Text = "Exporting Data..."
        $script:exportAppending = $false
        $script:pendingSecondExport = $false
        $type = if ($radioMDC.IsChecked) { "MDC" } else { "MCSB" }
        Start-Export -ExportType $type
    }
}

$btnCancel.Add_Click({
    if ($script:exportRunning -and $script:exportSync) {
        $script:exportSync.Cancel = $true
        $script:pendingSecondExport = $false
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Step 7: Results
# ══════════════════════════════════════════════════════════════════════════════
function Initialize-ResultsStep {
    if ($radioBoth.IsChecked) {
        # Combined results for both exports
        $rMDC = $script:exportResults["MDC"]
        $rMCSB = $script:exportResults["MCSB"]
        $totalRecords = 0; $filesText = @()
        if ($rMDC) { $totalRecords += $rMDC.TotalRecords; $filesText += "MDC: $($rMDC.TotalRecords) records ($($rMDC.FileSize))" }
        if ($rMCSB) { $totalRecords += $rMCSB.TotalRecords; $filesText += "MCSB: $($rMCSB.TotalRecords) records ($($rMCSB.FileSize))" }

        $resultSubsQueried.Text = ($filesText -join "  |  ")
        $resultTotalRecords.Text = "Total records: $totalRecords"
        $resultDuration.Text = "Duration: " + $(if ($rMDC) { "MDC $($rMDC.Duration)" } else { "" }) + $(if ($rMCSB) { "  MCSB $($rMCSB.Duration)" } else { "" })
        $resultFileSize.Text = ""

        if ($rMDC -and $rMDC.SecureScore) {
            $resultSecureScore.Text = "Defender for Cloud Secure Score: $($rMDC.SecureScore)%"
            $resultSecureScore.Visibility = "Visible"
        } else { $resultSecureScore.Visibility = "Collapsed" }

        $resultFilePath.Text = $script:outputFolder

        # Auto-check both
        if ($rMDC) { $chkMDC.IsChecked = $true; if ($rMDC.SecureScore) { $chkDfcScore.IsChecked = $true } }
        if ($rMCSB) { $chkMCSB.IsChecked = $true }
    } else {
        $exportType = if ($radioMDC.IsChecked) { "MDC" } else { "MCSB" }
        $r = $script:exportResults[$exportType]
        if (-not $r) { return }

        $resultSubsQueried.Text = "Subscriptions queried: $($r.SubsQueried) ($($r.SubsOk) OK, $($r.SubsFailed) failed)"
        $resultTotalRecords.Text = "Total records: $($r.TotalRecords)"
        $resultDuration.Text = "Duration: $($r.Duration)"
        $resultFileSize.Text = "File size: $($r.FileSize)"

        if ($r.SecureScore) {
            $resultSecureScore.Text = "Defender for Cloud Secure Score: $($r.SecureScore)%"
            $resultSecureScore.Visibility = "Visible"
        } else {
            $resultSecureScore.Visibility = "Collapsed"
        }

        $resultFilePath.Text = $script:exportOutputFile

        # Auto-check checklist
        if ($exportType -eq "MDC") { $chkMDC.IsChecked = $true; if ($r.SecureScore) { $chkDfcScore.IsChecked = $true } }
        else { $chkMCSB.IsChecked = $true }
    }

    # Warnings — show per-subscription verified DfC readiness
    $summaryLines = @()
    if ($script:permissionFails.Count -gt 0) {
        $summaryLines += "$([char]0x274C)  Missing permissions: $($script:permissionFails.Count) subscription(s)"
    }

    # Per-subscription DfC readiness from verified post-export results (skip OK entries)
    $selectedSubIds = @($script:allSubCheckboxes | Where-Object { $_.IsChecked -eq $true } | ForEach-Object { $_.Tag })
    $subNameMap = @{}; foreach ($s in $script:subscriptions) { $subNameMap[$s.Id] = $s.Name }
    $dfcFoundational = [System.Collections.Generic.List[string]]::new()
    $dfcNoData = [System.Collections.Generic.List[string]]::new()
    foreach ($subId in $selectedSubIds) {
        $subName = if ($subNameMap[$subId]) { $subNameMap[$subId] } else { $subId }
        $status = $script:subStatuses[$subId]
        if (-not $status) { continue }
        switch ($status.Readiness) {
            "Foundational CSPM only" { $dfcFoundational.Add($subName) }
            "No data returned"       { $dfcNoData.Add($subName) }
        }
    }

    # Build summary counts
    if ($dfcFoundational.Count -gt 0) { $summaryLines += "$([char]0x26A0)  Foundational CSPM only: $($dfcFoundational.Count) subscription(s)" }
    if ($dfcNoData.Count -gt 0)       { $summaryLines += "$([char]0x26A0)  No data returned: $($dfcNoData.Count) subscription(s)" }

    $totalIssues = $dfcFoundational.Count + $dfcNoData.Count

    if ($summaryLines.Count -gt 0) {
        $resultWarningSummary.Text = $summaryLines -join "`n"

        # Build detail lines for all affected subscriptions
        $detailLines = [System.Collections.Generic.List[string]]::new()
        foreach ($n in $dfcFoundational) { $detailLines.Add("$([char]0x26A0)  $n `u{2014} Foundational CSPM only") }
        foreach ($n in $dfcNoData)       { $detailLines.Add("$([char]0x26A0)  $n `u{2014} No data returned") }

        if ($totalIssues -le 5) {
            # Few items — show inline, no expander needed
            $resultWarnings.Text = $detailLines -join "`n"
            $resultWarningExpander.Visibility = "Collapsed"
        } else {
            # Many items — show first 3 inline, rest in expander
            $resultWarnings.Text = ($detailLines | Select-Object -First 3) -join "`n"
            $remaining = $detailLines | Select-Object -Skip 3
            $resultWarningExpander.Header = "Show $($remaining.Count) more..."
            $resultWarningDetails.Text = $remaining -join "`n"
            $resultWarningExpander.Visibility = "Visible"
        }

        $resultWarningPanel.Visibility = "Visible"
    } else {
        $resultWarningSummary.Text = ""
        $resultWarnings.Text = ""
        $resultWarningDetails.Text = ""
        $resultWarningExpander.Visibility = "Collapsed"
        $resultWarningPanel.Visibility = "Collapsed"
    }
}

$btnOpenFile.Add_Click({
    if ($script:exportOutputFile -and (Test-Path $script:exportOutputFile)) {
        Start-Process $script:exportOutputFile
    }
})
$btnOpenFolder.Add_Click({
    if ($script:outputFolder -and (Test-Path $script:outputFolder)) {
        Start-Process "explorer.exe" -ArgumentList $script:outputFolder
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Step 9: Final Checklist & Report Generation
# ══════════════════════════════════════════════════════════════════════════════
function Initialize-ChecklistStep {
    # Statistics
    $totalSubs = $script:subscriptions.Count
    $okSubs = @($script:subStatuses.Values | Where-Object { $_.Status -eq "OK" }).Count
    $permFails = @($script:subStatuses.Values | Where-Object { $_.Readiness -eq "Missing permissions" }).Count
    $notOnb = @($script:subStatuses.Values | Where-Object { $_.Readiness -match "not fully onboarded|Foundational CSPM only|No data returned" }).Count
    $otherErr = @($script:subStatuses.Values | Where-Object { $_.Readiness -eq "Other error" }).Count

    $statsTotal.Text = "Total subscriptions discovered: $totalSubs"
    $statsOk.Text = "Subscriptions with DfC data: $okSubs"
    $statsPermission.Text = "Excluded — missing permissions: $permFails"
    $statsNotOnboarded.Text = "Excluded — Foundational CSPM only: $notOnb"
    if ($otherErr -gt 0) { $statsNotOnboarded.Text += "`nExcluded — other errors: $otherErr" }

    $totalGaps = $permFails + $notOnb + $otherErr
    if ($totalGaps -gt 0) {
        $statsDataGaps.Text = "$([char]0x26A0) $totalGaps of $totalSubs subscription(s) have missing or incomplete data — see below"
        $statsDataGaps.Visibility = "Visible"
    } else {
        $statsDataGaps.Visibility = "Collapsed"
    }

    # Show CSA remediation if there are gaps
    if ($permFails -gt 0 -or $notOnb -gt 0 -or $otherErr -gt 0) {
        $csaRemediation.Visibility = "Visible"
    } else {
        $csaRemediation.Visibility = "Collapsed"
    }

    # Auto-fill MS Secure Score if entered
    if ($txtMsSecureScore.Text -match "^\d+(\.\d+)?$") {
        $script:msSecureScore = [double]$txtMsSecureScore.Text
        $chkMsScore.IsChecked = $true
    }
}

$btnSaveExportLog.Add_Click({
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $logPath = Join-Path $script:outputFolder "ESA_Export_Log_${timestamp}.txt"

    $ctx = Get-AzContext
    $tenantName = $script:selectedTenant.Name
    $tenantId = $script:selectedTenant.Id

    $lines = [System.Collections.Generic.List[string]]::new()
    $lines.Add("====================================================")
    $lines.Add(" Enterprise Security Assessment - Export Log")
    $lines.Add(" Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') UTC")
    $lines.Add("====================================================")
    $lines.Add("")
    $lines.Add("ENVIRONMENT")
    $lines.Add("  User:            $($ctx.Account)")
    $lines.Add("  Tenant:          $tenantName ($tenantId)")
    $lines.Add("  Tool Version:    1.1.0")
    $exportMode = if ($radioBoth.IsChecked) { "Both (MDC + MCSB)" } elseif ($radioMDC.IsChecked) { "MDC Recommendations" } else { "MCSB Compliance" }
    $lines.Add("  Export Mode:     $exportMode")
    $lines.Add("")
    $lines.Add("EXPORT SUMMARY")

    foreach ($type in @("MDC", "MCSB")) {
        $r = $script:exportResults[$type]
        if ($r) {
            $label = if ($type -eq "MDC") { "MDC Recommendations" } else { "MCSB Compliance" }
            $lines.Add("  ${label}:")
            $lines.Add("    Subscriptions queried:  $($r.SubsQueried) ($($r.SubsOk) OK, $($r.SubsFailed) failed)")
            $lines.Add("    Total records:          $($r.TotalRecords)")
            $lines.Add("    Output file:            $(Split-Path $r.OutputFile -Leaf) ($($r.FileSize))")
            $lines.Add("    Duration:               $($r.Duration)")
            $lines.Add("")
        }
    }

    $lines.Add("SECURE SCORES")
    if ($script:dfcSecureScore) {
        $lines.Add("  Defender for Cloud Secure Score:  $($script:dfcSecureScore)%")
    } else {
        $lines.Add("  Defender for Cloud Secure Score:  N/A")
    }
    if ($script:msSecureScore) {
        $lines.Add("  Microsoft Secure Score:           $($script:msSecureScore)%")
    } else {
        $lines.Add("  Microsoft Secure Score:           N/A")
    }
    $lines.Add("")

    $lines.Add("SUBSCRIPTION STATUS")
    $lines.Add("  #   Name                           Status      DfC Readiness")
    $idx = 0
    $selectedSubIds = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($cb in $script:allSubCheckboxes) { if ($cb.IsChecked) { $selectedSubIds.Add($cb.Tag) | Out-Null } }

    foreach ($sub in $script:subscriptions) {
        $idx++
        $wasSelected = $selectedSubIds.Contains($sub.Id)
        $status = $script:subStatuses[$sub.Id]
        $health = $script:dfcHealthStatus[$sub.Id]

        # Export status
        if (-not $wasSelected) {
            $st = "—"
        } elseif ($status) {
            $st = $status.Status
        } else {
            $st = "N/A"
        }

        # DfC Readiness: prefer post-export verified status, fall back to pre-export health check
        if ($status -and $wasSelected) {
            $rd = $status.Readiness
            # Enrich "Fully onboarded" with pre-export detail if partially onboarded
            if ($rd -eq "Fully onboarded" -and $health -and $health.TotalPlans -gt 0 -and $health.FreeCount -gt 0 -and $health.EnabledCount -gt 0) {
                $rd = "Partially onboarded"
            }
        } elseif ($health) {
            # Not exported — use pre-export health check
            if ($health.TotalPlans -gt 0 -and $health.FreeCount -eq 0) {
                $rd = "Fully onboarded"
            } elseif ($health.TotalPlans -gt 0 -and $health.EnabledCount -gt 0) {
                $rd = "Partially onboarded"
            } else {
                $rd = "Foundational CSPM only"
            }
        } else {
            $rd = "Unknown"
        }

        $truncName = $sub.Name.Substring(0, [math]::Min(30, $sub.Name.Length))
        $selected = if ($wasSelected) { "" } else { " (not selected)" }
        $lines.Add(("  {0,-3} {1,-30} {2,-12} {3}{4}" -f $idx, $truncName, $st, $rd, $selected))
    }
    $lines.Add("")

    $lines.Add("STATISTICS")
    $totalSubs = $script:subscriptions.Count
    $okSubs = @($script:subStatuses.Values | Where-Object { $_.Status -eq "OK" }).Count
    $permFails = @($script:subStatuses.Values | Where-Object { $_.Readiness -eq "Missing permissions" }).Count
    $notOnb = @($script:subStatuses.Values | Where-Object { $_.Readiness -match "not fully onboarded|Foundational CSPM only|No data returned" }).Count
    $otherErr = @($script:subStatuses.Values | Where-Object { $_.Readiness -eq "Other error" }).Count
    $lines.Add("  Total subscriptions discovered:     $totalSubs")
    $lines.Add("  Subscriptions with DfC data:        $okSubs")
    $lines.Add("  Excluded - missing permissions:      $permFails")
    $lines.Add("  Excluded - Foundational CSPM only:   $notOnb")
    $lines.Add("  Excluded - other errors:             $otherErr")
    $lines.Add("")

    # Errors
    if ($script:failedSubs.Count -gt 0) {
        $lines.Add("ERRORS")
        foreach ($f in $script:failedSubs) {
            $lines.Add("  $($f.Name) ($($f.Id)):")
            $lines.Add("    $($f.Error)")
        }
        $lines.Add("")
    }

    # Next Steps
    if ($permFails -gt 0 -or $notOnb -gt 0) {
        $lines.Add("NEXT STEPS")
        $lines.Add("  If subscriptions are missing data due to Defender for Cloud not being")
        $lines.Add("  onboarded, the involved CSA can support remediation of these gaps.")
        $lines.Add("  If needed, an additional Technical Blocker Mitigation VBD for Defender")
        $lines.Add("  for Cloud onboarding can be dispatched.")
        $lines.Add("")
        $lines.Add("  Options:")
        $lines.Add("    1. Proceed with the ESA based on the current data quality")
        $lines.Add("    2. Engage the CSA to remediate gaps before continuing")
        $lines.Add("")
    }

    $lines.Add("NOTE: Microsoft Defender XDR and Microsoft Purview data must be exported")
    $lines.Add("      manually and are not covered by this tool. Please refer to the data")
    $lines.Add("      gathering instructions for details.")
    $lines.Add("")
    $lines.Add("====================================================")
    $lines.Add("")
    $lines.Add("EXPORT LOG")
    $lines.Add("====================================================")
    $lines.Add($exportLog.Text)
    $lines.Add("====================================================")

    $lines | Out-File -FilePath $logPath -Encoding UTF8

    # ── Package all generated files into a ZIP ──
    $zipPath = Join-Path $script:outputFolder "ESA_Export_${timestamp}.zip"
    $filesToZip = @()

    # Add export log
    $filesToZip += $logPath

    # Add CSV output files from all export runs
    foreach ($type in @("MDC", "MCSB")) {
        $r = $script:exportResults[$type]
        if ($r -and $r.OutputFile -and (Test-Path $r.OutputFile)) {
            $filesToZip += $r.OutputFile
        }
    }

    # Add any .failed log files in output folder
    $failedFiles = Get-ChildItem -Path $script:outputFolder -Filter "*.failed" -ErrorAction SilentlyContinue
    if ($failedFiles) { $filesToZip += $failedFiles.FullName }

    # Create ZIP package
    $reportStatus.Text = "Creating ZIP package..."
    $btnSaveExportLog.IsEnabled = $false
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([System.Windows.Threading.DispatcherPriority]::Background, [Action]{})

    try {
        Compress-Archive -Path $filesToZip -DestinationPath $zipPath -Force
        $reportStatus.Text = "Saved: $zipPath"
    } catch {
        $reportStatus.Text = "Export log saved: $logPath (ZIP failed: $($_.Exception.Message))"
    }
    $btnSaveExportLog.IsEnabled = $true
})

$btnOpenOutputFolder.Add_Click({
    if ($script:outputFolder -and (Test-Path $script:outputFolder)) {
        Start-Process "explorer.exe" -ArgumentList $script:outputFolder
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Navigation Button Handlers
# ══════════════════════════════════════════════════════════════════════════════
$btnNext.Add_Click({
    switch ($script:currentStep) {
        0 { Set-WizardStep 1 }
        1 { Initialize-SignInStep; Set-WizardStep 2 }
        2 { Initialize-TenantStep; Set-WizardStep 3 }
        3 {
            # If tenant changed, may need re-auth
            if ($script:selectedTenant) {
                Initialize-SubscriptionStep
                Set-WizardStep 4
            }
        }
        4 { Initialize-OutputStep; Set-WizardStep 5 }
        5 {
            # Start Export
            Set-WizardStep 6
            Start-ExportSequence
        }
        7 { Set-WizardStep 8 }
        8 { Initialize-ChecklistStep; Set-WizardStep 9 }
        9 { $window.Close() }
    }
})

$btnBack.Add_Click({
    switch ($script:currentStep) {
        1 { Set-WizardStep 0 }
        2 { Set-WizardStep 1 }
        3 { Set-WizardStep 2 }
        4 { Set-WizardStep 3 }
        5 { Set-WizardStep 4 }
        7 { Set-WizardStep 5 }
        8 { Set-WizardStep 7 }
        9 { Set-WizardStep 8 }
    }
})

# ══════════════════════════════════════════════════════════════════════════════
# Initialize and Show
# ══════════════════════════════════════════════════════════════════════════════
Test-Prerequisites
Set-WizardStep 0
$window.ShowDialog() | Out-Null
